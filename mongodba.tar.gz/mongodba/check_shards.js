
try {

use config
}
catch(err)
{
	print("Error: switching ");
	quit();	
}

var items=db.shards.find()

items.forEach(function(item)
{
	printjson(item);
	print(item._id);
	print(item.host);
}
)
quit()
