
use config

db.shards.find()

db.shards.update ({"_id" : "Mongo-users2"}
	,{
		$set: {host : "Mongo-users2/qa2-mongo-usr103:37017,qa2-mongo-usr104:37017" }
	}
)
{ getLastError: 1 }

db.shards.update ({"_id" : "Mongo-users3"}
	,{
		$set: {host : "Mongo-users3/qa2-mongo-usr105:37017,qa2-mongo-usr106:37017"}
	}
)
{ getLastError: 1 }

db.shards.update ({"_id" : "Mongo-users1"}
	,{
		$set: {host : "Mongo-users1/qa2-mongo-usr101:37017,qa2-mongo-usr102:37017"}
	}
)
{ getLastError: 1 }

db.shards.find()
