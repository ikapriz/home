
config={
        "_id" : "Mongo-FAC",
        "members" : [
                {
                        "_id" : 10,
                        "host" : "qa2-mongo-fac101:37017"
                },
                {
                        "_id" : 11,
                        "host" : "qa2-mongo-fac102:37017"
                },
                {
                        "_id" : 12,
                        "host" : "qa2-mongo-fac103:37017"
                },
                {
                        "_id" : 13,
                        "host" : "qa2-mongo-fac104:37017",
                        "priority" : 0,
                        "hidden" : true
                }
        ]
}

rs.initiate(config)
