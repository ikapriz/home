use config
db.getMongo().setSlaveOk();
db.shards.find().forEach(function(obj) {
	print(obj._id+" "+obj.host);
});
quit()
