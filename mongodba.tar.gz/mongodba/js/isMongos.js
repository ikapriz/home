use  config; 
db.getMongo().setSlaveOk(); 
var item=db.runCommand({ isdbgrid : 1 });
if(db.getLastError() != null){
	print("Error" + db.getLastError());
	quit(2);
}
quit(item.ok+5)
