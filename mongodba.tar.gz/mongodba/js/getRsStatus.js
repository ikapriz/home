db.getMongo().setSlaveOk();
var rt=0
rs.status().members.forEach(function(obj) {
	print(obj.name+" "+obj.stateStr);
	if (obj.stateStr != "PRIMARY" && obj.stateStr != "ARBITER" && obj.stateStr != "SECONDARY"){rt=1}
});
quit(rt)
