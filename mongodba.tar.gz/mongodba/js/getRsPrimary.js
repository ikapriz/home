db.getMongo().setSlaveOk();
rs.status().members.forEach(function(obj) {
	if (obj.state == 1) {print(obj.name);}
});
quit()
