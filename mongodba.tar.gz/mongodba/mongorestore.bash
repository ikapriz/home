#!/bin/bash
# server must be down!


mongorestore --dbpath /data/db/mongo --journal /data/uncompressed

