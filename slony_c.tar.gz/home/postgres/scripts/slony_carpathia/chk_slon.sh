#/bin/bash

DIR=/home/postgres/scripts/slony_carpathia;

num_slon=`ps axu|grep "slon -f" |grep -v "grep"|wc -l`;

if [[ $num_slon -ne 4 ]]
then
  cat ${DIR}/README | /usr/bin/mutt CCRDDatabaseOperations@clearchannel.com -s "Check slon on carpathia ING!!";
fi;

