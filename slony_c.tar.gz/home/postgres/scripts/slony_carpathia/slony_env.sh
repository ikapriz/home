#PostgreSQL related env variables
PGPATH=/usr/pgsql-9.1/bin

# Slony global variable to pass in configure_replication.sh script
SLONIKCONFDIR=/home/postgres/scripts/slony_carpathia/slonikqa_cluster
SLONIKPATH=/usr/pgsql-9.1/bin/slonik
SLONBIN=/usr/pgsql-9.1/bin
# Directory for slon Configuration files
SLHOME=/home/postgres/scripts/slony_carpathia/slonikqa_cluster
# Directory for slon Log files
LOGHOME=/data/slony

CLUSTER=ms_ingestion


