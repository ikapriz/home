log_level                :info
log_location             STDOUT
node_name                'ikaprizkina'
client_key               '/home/ikaprizkina/.chef/client.pem'
validation_client_name   'chef-validator'
validation_key           '/home/ikaprizkina/.chef/chef-validator.pem'
chef_server_url          'https://iad-qac1-admin101.ihr'
